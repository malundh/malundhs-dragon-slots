MALUNDH’S DRAGON SLOTS – Android Studio-projekt

Detta är ett Android Studio-projekt som visar hela det befintliga spelet
i en inbyggd Android WebView. Spelets HTML-fil ligger lokalt i:
app/src/main/assets/index.html

Bygg APK:
1. Installera Android Studio på en dator.
2. Packa upp ZIP-filen.
3. Öppna mappen MalundhsDragonSlots i Android Studio.
4. Låt Android Studio synkronisera Gradle och installera nödvändiga SDK-delar.
5. Välj Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK-filen skapas normalt under app/build/outputs/apk/debug/app-debug.apk.

Appen är inställd för stående läge, helskärm och lokal/offline HTML.
Ingen nätverksbehörighet används. Testa spelet på enheten efter byggning.

OBS: Denna leverans är Android-projektets källfiler, inte en färdigkompilerad
APK. Den här miljön saknar Android SDK/Gradle-installation för att bygga APK här.
